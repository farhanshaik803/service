import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  displayData(val : string){
    console.log(val);
  }

  constructor() { }
}
